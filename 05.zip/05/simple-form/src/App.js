import "./App.css";
import { useState } from "react";
import Form from "./components/Form";

function App() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [step2, setStep2] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    // comparer les 2 mots de passe
    if (password === confirmPassword) {
      setStep2(true);
    } else {
      alert("Vos mots de passe ne sont pas identiques !");
    }
  };

  return (
    <div>
      {step2 === false ? (
        <Form
          handleSubmit={handleSubmit}
          setUsername={setUsername}
          username={username}
          setEmail={setEmail}
          email={email}
          setPassword={setPassword}
          password={password}
          setConfirmPassword={setConfirmPassword}
          confirmPassword={confirmPassword}
        />
      ) : (
        <div>
          Résultats
          <p>Username : {username}</p>
          <p>Email : {email}</p>
          <p>Password : {password}</p>
          <button onClick={() => setStep2(false)}>
            Edit your informations
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
