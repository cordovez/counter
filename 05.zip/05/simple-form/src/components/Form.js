const Form = ({
  username,
  setUsername,
  email,
  setEmail,
  password,
  setPassword,
  confirmPassword,
  setConfirmPassword,
  handleSubmit,
}) => {
  return (
    <form onSubmit={handleSubmit}>
      <input
        onChange={(event) => {
          setUsername(event.target.value);
        }}
        value={username}
        type="text"
      />
      <br />
      <input
        onChange={(event) => {
          setEmail(event.target.value);
        }}
        value={email}
        type="email"
      />
      <br />
      <input
        onChange={(event) => {
          setPassword(event.target.value);
        }}
        value={password}
        type="password"
      />
      <br />
      <input
        onChange={(event) => {
          setConfirmPassword(event.target.value);
        }}
        value={confirmPassword}
        type="password"
      />
      <br />
      <input type="submit" />
    </form>
  );
};

export default Form;
