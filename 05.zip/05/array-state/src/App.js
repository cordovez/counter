import "./App.css";
import { useState } from "react";
import Help from "./Help";

function App() {
  const [tab, setTab] = useState([1, 2, 3]);

  return (
    <div className={"App"}>
      {tab}
      <br />
      <button
        onClick={() => {
          // Créer une copie de tab
          const newTab = [...tab];
          // Modifier la copie
          newTab.push(4);
          // Mettre à jour le state avec la copie
          setTab(newTab);
        }}
      >
        Ajouter 4 dans le tableau
      </button>
      <Help />
    </div>
  );
}

export default App;
