import { useState } from "react";

const Help = () => {
  const [counters, setCounters] = useState([0, 0, 0]);

  return (
    <div>
      {counters.map((counter, index) => {
        return (
          <div>
            {counter}
            <button>Increment</button>
          </div>
        );
      })}
      <button>Add counter</button>
    </div>
  );
};

export default Help;
