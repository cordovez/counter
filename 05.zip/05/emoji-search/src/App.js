import "./App.css";
import emojiList from "./emojiList.json";
import { useState } from "react";

function App() {
  const [results, setResults] = useState(emojiList.slice(0, 20));

  const handleChange = (event) => {
    // chercher si event.target.value est présent dans les keywords de chaque emoji ?
    const newResults = [];
    for (let i = 0; i < emojiList.length; i++) {
      if (
        emojiList[i].keywords.indexOf(event.target.value.toLowerCase()) !== -1
      ) {
        // est-ce que j'ai pas déjà 20 résultats ?
        if (newResults.length >= 20) {
          // je sors de la boucle
          break;
        } else {
          // si oui ===> on push l'emoji dans un tableau
          newResults.push(emojiList[i]);
        }
      }
      // sinon ===> on fait rien
    }
    // on met à jour le state results avec le tableau
    setResults(newResults);
  };

  return (
    <div>
      {/* Input pour chercher */}
      <input onChange={handleChange} type="text" />
      {/* List de résultats */}
      {results.map((emoji, index) => {
        return (
          <div>
            <span>{emoji.symbol}</span>
            <span>{emoji.title}</span>
          </div>
        );
      })}
    </div>
  );
}

export default App;
